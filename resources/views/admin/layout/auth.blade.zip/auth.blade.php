<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Laravel Multi Auth Guard') }}</title>

    <!-- Styles -->
    <link href="/css/app.css" rel="stylesheet">

    <!-- Scripts -->
    <script>
        window.Laravel = <?php echo json_encode([
            'csrfToken' => csrf_token(),
        ]); ?>
    </script>
    <style type="text/css">
    ul {
        list-style-type: none;
        margin: 0;
        padding: 0;
        width: 200px;
        background-color: #f1f1f1;
    }

    li a {
        display: block;
        color: #000;
        padding: 20px 16px;
        text-decoration: none;
        font-size: 20px;
    }

    /* Change the link color on hover */
    li a:hover {
        background-color: #555;
        color: white;
    }

    li a:focus{
        background-color: #555;
        color: white;
    }

    html,body{
        margin: 0;
        padding: 0;
    }

    .sideMenuBar{
        height: 100%;
        position: fixed;
        z-index: 1;
        margin-top: 120px;
    }

    .header{
        z-index: 2;
        position: fixed;
        width: 100%;
        background-color: #b7b7b7;
        display: table;
    }

    .footer{
        width: 100%;
        background-color: #b7b7b7;
        position: absolute;
        z-index: 1;
        bottom: 0;
        text-align: center;
        padding: 20px 0px;
    }

    .profile{
        display: table-cell;
        text-align: right;
        width: 30%;
        padding: 0;
        vertical-align: middle; 
        padding-right: 20px;
    }
</style>
</head>
<body onload="renderTime();">
<div class="header">
        <table style="padding: 10px; width: 70%;"> 
            <tr> 
                <th rowspan="2"><img src="/../mkp-icon.png" style="padding: 15px;"></th> 
                <td style="padding: 0px; margin: 0px; font-size: 30px;">PT. MANDIRI KONSULTAMA PERKASA</td> 
            </tr> 
            <tr>
                <td style="padding: 0px; margin: 0px; font-size: 30px;">PAYROLL SYSTEM</td> 
            </tr> 
        </table> 

        <div class="profile">
            <table style="float: right; margin-right: 20px;">
                <tr>
                    <td style="padding: 0px; margin: 0px; font-size: 20px;">
                        <li class="dropdown" style="display: inline-block;">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false" style="padding-top: 0;">
                                {{ Auth::user()->name }}<span class="caret"></span>
                            </a>

                            <ul class="dropdown-menu" role="menu">
                                <li>
                                    <a href="{{ url('/admin/logout') }}"
                                        onclick="event.preventDefault();
                                                 document.getElementById('logout-form').submit();">
                                        Logout
                                    </a>

                                    <form id="logout-form" action="{{ url('/admin/logout') }}" method="POST" style="display: none;">
                                        {{ csrf_field() }}
                                    </form>
                                </li>
                            </ul>
                        </li>
                    </td> 
                </tr> 
                <tr>
                    <td style="padding: 0px; margin: 0px; font-size: 20px;" ><div id="clockDisplay"></div></td>
                </tr>
            </table>
        </div>
    </div>

    <ul class="sideMenuBar">
        <li><a href="#karyawan">Karyawan</a></li>
        <li><a href="#payroll">Payroll</a></li>
    </ul>
    <!-- <nav class="navbar navbar-default navbar-static-top">
        <div class="container">
            <div class="navbar-header"> -->

                <!-- Collapsed Hamburger -->
                <!-- <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse">
                    <span class="sr-only">Toggle Navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button> -->

                <!-- Branding Image -->
                <!-- <a class="navbar-brand" href="{{ url('/') }}">
                    {{ config('app.name', 'Laravel Multi Auth Guard') }}: Admin
                </a>
            </div> -->

            <!-- <div class="collapse navbar-collapse" id="app-navbar-collapse"> -->
                <!-- Left Side Of Navbar -->
                <!-- <ul class="nav navbar-nav">
                    &nbsp;
                </ul>
 -->
                <!-- Right Side Of Navbar -->
                <!-- <ul class="nav navbar-nav navbar-right"> -->
                    <!-- Authentication Links -->
                    <!-- @if (Auth::guest())
                        <li><a href="{{ url('/admin/login') }}">Login</a></li>
                        <li><a href="{{ url('/admin/register') }}">Register</a></li>
                    @else
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                {{ Auth::user()->name }} <span class="caret"></span>
                            </a>

                            <ul class="dropdown-menu" role="menu">
                                <li>
                                    <a href="{{ url('/admin/logout') }}"
                                        onclick="event.preventDefault();
                                                 document.getElementById('logout-form').submit();">
                                        Logout
                                    </a>

                                    <form id="logout-form" action="{{ url('/admin/logout') }}" method="POST" style="display: none;">
                                        {{ csrf_field() }}
                                    </form>
                                </li>
                            </ul>
                        </li>
                    @endif
                </ul>
            </div>
        </div>
    </nav> -->

    @yield('content')

    <!-- Scripts -->
    <script src="/js/app.js"></script>
    <script>
        function renderTime(){

            // Date
            var mydate = new Date();
            var year = mydate.getYear();
                if(year < 1000){
                    year += 1900
                }
            var day = mydate.getDay();
            var month = mydate.getMonth();
            var daym = mydate.getDate();
            var dayarray = new Array("Minggu,", "Senin,", "Selasa,", "Rabu,", "Kamis,", "Jumat,", "Sabtu,");
            var montharray = new Array("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");
            // Date End

            // Time
            var currentTime = new Date();
            var h = currentTime.getHours();
            var m = currentTime.getMinutes();
            var s = currentTime.getSeconds();
                if(h == 24){
                    h=0;
                } else if(h > 12){
                    h = h - 0;
                }

                if( h < 10){
                    h = "0" + h;
                }

                if(m < 10){
                    m = "0" + m;
                }

                if(s < 10){
                    s = "0" + s;
                }

                var myClock = document.getElementById("clockDisplay");
                myClock.textContent = "" +dayarray[day]+ " "+ daym + " " + montharray[month]+ " "+ year+ " | " + h + ";" + m + ":" + s;
                myClock.innerText = "" +dayarray[day]+ " "+ daym + " " + montharray[month]+ " "+ year+ " | " + h + ";" + m + ":" + s;

                setTimeout("renderTime()", 500);
        }

        renderTime();
    </script>
</body>
</html>
