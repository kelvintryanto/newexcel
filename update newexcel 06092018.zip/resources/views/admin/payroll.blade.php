@extends('admin.layout.auth')

@section('content')
<div class="container" style="margin-left: 0px; margin-right: 0px; padding: 15px; width: 100%;">
    <div class="row">
        <div class="col-md-12">

            <!-- tambahan accordion uploading -->
            <div>
                <button class="accordion">Upload Payroll</button>
                <div class="panel-accordion">
                    <form class="form-horizontal" method="POST" action="{{ route('import_parse') }}" enctype="multipart/form-data">
                        {{ csrf_field() }}

                        <div class="form-group{{ $errors->has('csv_file') ? ' has-error' : '' }}">
                            <label for="csv_file" class="col-md-4 control-label">CSV file to import</label>

                            <div class="col-md-6">
                                <input id="csv_file" type="file" class="form-control" name="csv_file" required>

                                @if ($errors->has('csv_file'))
                                <span class="help-block">
                                    <strong>{{ $errors->first('csv_file') }}</strong>
                                </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <div class="checkbox">
                                    <label>
                                        <input type="checkbox" name="header" checked> File contains header row?
                                    </label>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-8 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    Parse CSV
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <!-- end of tambahan accordion uploading -->

            <!-- panel uploader -->
            <!-- <div class="panel panel-default">
                <div class="panel-heading">PAYROLL</div><br>  
                
                <div class="panel-body">
                    You are logged in as Admin!
                </div>

                <form class="form-horizontal" method="POST" action="{{ route('import_parse') }}" enctype="multipart/form-data">
                    {{ csrf_field() }}

                    <div class="form-group{{ $errors->has('csv_file') ? ' has-error' : '' }}">
                        <label for="csv_file" class="col-md-4 control-label">CSV file to import</label>

                        <div class="col-md-6">
                            <input id="csv_file" type="file" class="form-control" name="csv_file" required>

                            @if ($errors->has('csv_file'))
                            <span class="help-block">
                                <strong>{{ $errors->first('csv_file') }}</strong>
                            </span>
                            @endif
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="col-md-6 col-md-offset-4">
                            <div class="checkbox">
                                <label>
                                    <input type="checkbox" name="header" checked> File contains header row?
                                </label>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="col-md-8 col-md-offset-4">
                            <button type="submit" class="btn btn-primary">
                                Parse CSV
                            </button>
                        </div>
                    </div>
                </form>
            </div> -->
            <!-- end of panel uploader -->

            <div style="margin-top: 20px; overflow-x: auto; width: 100%;">
                <table class="table table-hover scrollable pointer" style="font-size: 12px;" border="1">
                    <tr>
                        <th>No.ID</th> 
                        <th>Nama</th>
                        <th>CD Jenis Penghasilan</th>
                        <th>Keterangan Penghasilan</th>
                        <th>Code Channel Jabatan</th>
                        <th>Channel Jabatan</th>
                        <th>Jabatan</th>
                        <th>Jumlah Hari Kerja</th>
                        <th>Commision</th>
                        <th>Override</th>
                        <th>Monthly Performance</th>
                        <th>Quarterly Production</th>
                        <th>Monthly Recruit</th>
                        <th>Operational Allowance</th>
                        <th>Other Allowance</th>
                        <th>Other Allowance 1</th>
                        <th>Other Allowance 2</th>
                        <th>Other Allowance 3</th>
                        <th>Tax Allowance</th>
                        <th>Sub Total Penerimaan</th>
                        <th>Uang Muka</th>
                        <th>Pemotongan 1</th>
                        <th>Pemotongan 2</th>
                        <th>Pemotongan 3</th>
                        <th>Pemotongan 4</th>
                        <th>Pemotongan 5</th>
                        <th>Pemotongan 6</th>
                        <th>Pemotongan 7</th>
                        <th>Pemotongan </th>
                        <th>PPH 21 Final</th>
                        <th>PPH 21 Non Final</th>
                        <th>PPH 21/26</th>
                        <th>Sanksi Pajak</th>
                        <th>Sub Total Potongan</th>
                        <th>Nilai Dibayar</th>
                    </tr>
                    <?php
                    $conn=mysqli_connect("localhost","root","","newexcel");
                    if($conn->connect_error){
                        die("Connection failed:". $conn-> connect_error);
                    }
                    $sql = "SELECT nama,ptkp,email from karyawan, users WHERE karyawan.nama = users.name";
                    $result = $conn-> query($sql);


                    if ($result-> num_rows > 0) {
                        while ($row = $result-> fetch_assoc()) {
                            echo "<tr><td>".$row["nama"]."</td><td>".$row["ptkp"]."</td><td>".$row["email"]."</td></tr>";

                        }
                        echo "</table>";
                    }
                    else{
                        echo "0 result";
                    }
                    $conn-> close();
                    ?> 


                </table>
            </div>
            <!-- <div>
                <form action="send" method="post">
                    {{csrf_field()}}
                    to: <input type="text" name="to">
                    message: <textarea name="message" cols="30" rows="10"></textarea>
                    <input type="submit" value="Send">
                </form>
            </div> -->

            <!-- </div> -->
        </div>
    </div>
</div>
</div>
@endsection